import React, { useState } from 'react';
import PatientForm from './components/PatientForm';
import PatientList from './components/PatientList';
import { Patient } from '../src/types';
import './styles/App.css';

const App: React.FC = () => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [currentPatient, setCurrentPatient] = useState<Patient | null>(null);
  const [editIndex, setEditIndex] = useState<number | null>(null);

  const handleSavePatient = (patient: Patient) => {
    if (editIndex !== null) {
      const updatedPatients = [...patients];
      updatedPatients[editIndex] = patient;
      setPatients(updatedPatients);
      setEditIndex(null);
    } else {
      setPatients([...patients, patient]);
    }
    setCurrentPatient(null);
  };

  const handleEditPatient = (index: number) => {
    setCurrentPatient(patients[index]);
    setEditIndex(index);
  };

  const handleDeletePatient = (index: number) => {
    const updatedPatients = patients.filter((_, i) => i !== index);
    setPatients(updatedPatients);
  };

  return (
    <div className="App">
      <h1>ToothFixers Ltd.</h1>
      <PatientForm onSave={handleSavePatient} />
      <PatientList patients={patients} onEdit={handleEditPatient} onDelete={handleDeletePatient} />
    </div>
  );
};

export default App;
