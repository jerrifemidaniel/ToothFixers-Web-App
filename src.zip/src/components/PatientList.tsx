import React from 'react';
import { Patient } from '../types';
import '../styles/PatientList.css';

interface PatientListProps {
  patients: Patient[];
  onEdit: (index: number) => void;
  onDelete: (index: number) => void;
}

const PatientList: React.FC<PatientListProps> = ({ patients, onEdit, onDelete }) => {
  return (
    <div className="patient-list">
      <h2>Patients</h2>
      <table>
        <thead>
          <tr>
            <th>First Name</th>
            <th>Surname</th>
            <th>Middle Name</th>
            <th>Date of Birth</th>
            <th>Home Address</th>
            <th>Registration Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {patients.map((patient, index) => (
            <tr key={index}>
              <td>{patient.firstName}</td>
              <td>{patient.surname}</td>
              <td>{patient.middleName}</td>
              <td>{patient.dob}</td>
              <td>{patient.address}</td>
              <td>{patient.registrationDate}</td>
              <td>
                <button onClick={() => onEdit(index)}>Edit</button>
                <button onClick={() => onDelete(index)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PatientList;
