import React from 'react';
import { ClinicalRecord } from '../types';
import '../styles/ClinicalRecordDetail.css';

interface ClinicalRecordDetailProps {
  record: ClinicalRecord;
}

const ClinicalRecordDetail: React.FC<ClinicalRecordDetailProps> = ({ record }) => {
  return (
    <div className="clinical-record-detail">
      <h2>Clinical Record Details</h2>
      <p><strong>Clinic Date:</strong> {record.clinicDate}</p>
      <p><strong>Ailment:</strong> {record.ailment}</p>
      <p><strong>Medicine:</strong> {record.medicine}</p>
      <p><strong>Procedure:</strong> {record.procedure}</p>
      <p><strong>Next Appointment:</strong> {record.nextAppointment}</p>
    </div>
  );
};

export default ClinicalRecordDetail;
