import React from 'react';
import { ClinicalRecord } from '../types';
import '../styles/ClinicalRecordList.css';

interface ClinicalRecordListProps {
  records: ClinicalRecord[];
  onEdit: (index: number) => void;
  onDelete: (index: number) => void;
}

const ClinicalRecordList: React.FC<ClinicalRecordListProps> = ({ records, onEdit, onDelete }) => {
  return (
    <div className="clinical-record-list">
      <h2>Clinical Records</h2>
      <table>
        <thead>
          <tr>
            <th>Clinic Date</th>
            <th>Ailment</th>
            <th>Medicine</th>
            <th>Procedure</th>
            <th>Next Appointment</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {records.map((record, index) => (
            <tr key={index}>
              <td>{record.clinicDate}</td>
              <td>{record.ailment}</td>
              <td>{record.medicine}</td>
              <td>{record.procedure}</td>
              <td>{record.nextAppointment}</td>
              <td>
                <button onClick={() => onEdit(index)}>Edit</button>
                <button onClick={() => onDelete(index)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ClinicalRecordList;
