import React, { useState, ChangeEvent, FormEvent } from 'react';
import { ClinicalRecord } from '../types';
import '../styles/ClinicalRecordForm.css';

interface ClinicalRecordFormProps {
  onSave: (record: ClinicalRecord) => void;
}

const ClinicalRecordForm: React.FC<ClinicalRecordFormProps> = ({ onSave }) => {
  const [formData, setFormData] = useState<ClinicalRecord>({
    clinicDate: '',
    ailment: '',
    medicine: '',
    procedure: '',
    nextAppointment: ''
  });

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSave(formData);
    setFormData({
      clinicDate: '',
      ailment: '',
      medicine: '',
      procedure: '',
      nextAppointment: ''
    });
  };

  return (
    <form className="clinical-record-form" onSubmit={handleSubmit}>
      <div>
        <label>Clinic Date:</label>
        <input type="date" name="clinicDate" value={formData.clinicDate} onChange={handleChange} required />
      </div>
      <div>
        <label>Ailment:</label>
        <input type="text" name="ailment" value={formData.ailment} onChange={handleChange} required />
      </div>
      <div>
        <label>Medicine:</label>
        <input type="text" name="medicine" value={formData.medicine} onChange={handleChange} />
      </div>
      <div>
        <label>Procedure:</label>
        <input type="text" name="procedure" value={formData.procedure} onChange={handleChange} />
      </div>
      <div>
        <label>Next Appointment:</label>
        <input type="date" name="nextAppointment" value={formData.nextAppointment} onChange={handleChange} />
      </div>
      <button type="submit">Save</button>
    </form>
  );
};

export default ClinicalRecordForm;
