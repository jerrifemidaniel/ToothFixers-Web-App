import React from 'react';
import { Patient } from '../types';
import '../styles/PatientDetail.css';

interface PatientDetailProps {
  patient: Patient;
}

const PatientDetail: React.FC<PatientDetailProps> = ({ patient }) => {
  return (
    <div className="patient-detail">
      <h2>Patient Details</h2>
      <p><strong>First Name:</strong> {patient.firstName}</p>
      <p><strong>Surname:</strong> {patient.surname}</p>
      <p><strong>Middle Name:</strong> {patient.middleName}</p>
      <p><strong>Date of Birth:</strong> {patient.dob}</p>
      <p><strong>Home Address:</strong> {patient.address}</p>
      <p><strong>Registration Date:</strong> {patient.registrationDate}</p>
    </div>
  );
};

export default PatientDetail;
