import React, { useState, ChangeEvent, FormEvent } from 'react';
import { Patient } from '../types';
import '../styles/PatientForm.css';

interface PatientFormProps {
  onSave: (patient: Patient) => void;
}

const PatientForm: React.FC<PatientFormProps> = ({ onSave }) => {
  const [formData, setFormData] = useState<Patient>({
    firstName: '',
    surname: '',
    middleName: '',
    dob: '',
    address: '',
    registrationDate: '',
    matriculationNumber: '_334942894723'
  });

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSave(formData);
    setFormData({
      firstName: '',
      surname: '',
      middleName: '',
      dob: '',
      address: '',
      registrationDate: '',
      matriculationNumber: '_334942894723'
    });
  };

  return (
    <form className="patient-form" onSubmit={handleSubmit}>
      <div>
        <label>First Name:</label>
        <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} required />
      </div>
      <div>
        <label>Surname:</label>
        <input type="text" name="surname" value={formData.surname} onChange={handleChange} required />
      </div>
      <div>
        <label>Middle Name:</label>
        <input type="text" name="middleName" value={formData.middleName} onChange={handleChange} />
      </div>
      <div>
        <label>Date of Birth:</label>
        <input type="date" name="dob" value={formData.dob} onChange={handleChange} required />
      </div>
      <div>
        <label>Home Address:</label>
        <input type="text" name="address" value={formData.address} onChange={handleChange} required />
      </div>
      <div>
        <label>Date of Registration:</label>
        <input type="date" name="registrationDate" value={formData.registrationDate} onChange={handleChange} required />
      </div>
      <button type="submit">Save</button>
    </form>
  );
};

export default PatientForm;
